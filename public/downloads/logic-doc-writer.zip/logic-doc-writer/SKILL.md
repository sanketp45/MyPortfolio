---
name: "logic-doc-writer"
description: "Read a Figma journey design file in detail and write its logic doc as yellow logic cards with pointers on a new page, for developers, QA and PMs."
---

# Logic Doc Writer

Writes the logic document for a delivery design file directly in Figma. The final logic lives only in Figma, as yellow logic cards next to the real screens. Readers are developers, QA and PM/business, so every card must leave nothing to guesswork.

## Inputs

* Figma journey design file link (page or node). Section names, label bars and screen headings describe the flow.
* Optional PRD, BRD or JIRA stories. When given, their rules override the defaults in this skill.

## Workflow

### 1. Start

1. Load the figma-use skill before any use_figma call.
2. Parse fileKey and nodeId from the link and call create_session.
3. Check edit access before deep reading: in use_figma, create a temp page and remove it. If it fails with a read only error, tell the user and ask them to get edit access or duplicate the file. Do not build anything until access works.

### 2. Read the file in detail (never skip)

1. List pages and top level nodes on the target page. Identify journey sections, loose frames, label bars and flow arrows. Vectors named "A --> B" show where a tap leads.
2. If the page holds several versions of the same screen, ask which frames to document (often the latest ones on the far right) and diff their text against the others.
3. For every base screen, extract visible text section by section and screenshot each section with node.screenshot().
4. Screenshot every scenario section, drawer and widget state. Note every state: default, typing, selected, error, logged in, non logged in, resume, success.
5. Collect design issues while reading: typos, wrong or swapped labels, scenario labels that do not match the flow, screens that do not update after a change, placeholder copy.

### 3. Plan the page

1. Create a new page named "Logic Doc (<flow name>)" right after the source page, unless the user names an existing Logic page.
2. Logic sections mirror the journey design's own sections and names. Every section has a black fill.
3. Base section: one base screen per section, with logic cards on both sides.
4. Scenario sections cover only what changes for that scenario, not the whole flow. Place the actual scenario screens and attach each card to its element with a pointer.
5. Drawers, popups and component states that belong to one element go inside that element's card: info drawers, share sheet, chip selected, typing, input error states, widget states.
6. No logic cards for the header or footer (global chrome). Skip static disclaimers unless they hold a link.
7. Do not run a per component data checklist (source, fallback, overflow, states, user state). Write only what the element needs.

### 4. Build

1. Create the page and black sections. Clone screens from the source page into the sections. Load every font used in a node before appending its clone.
2. Base section layout: base screen at x 620, y 260 inside the section, green label bar above it. Cards sit 90 px left or right of the screen.
3. Place each card level with its target: card top = target centre y minus 23. Keep at least 40 px between cards on the same side. Pick the side that needs the smaller push; alternate when equal. Use both sides of the screen.
4. Scenario section layout: rows of screens, each with a step label bar above it ("1. Select brand"). Card sits 70 px right of its screen, top aligned with the screen. 100 px between steps, 160 px between rows. A dark row label bar spans each row ("Non logged in", "Logged in", "Typing scenario").
5. Draw one pointer per card from the card edge to the target element. Straight line when the target is within the card's height, otherwise an elbow 40 px out from the card. Keep pointers short and uncrowded.
6. Number cards in reading order, restarting at 1 in each section.
7. Resize each section to fit its content plus 120 px padding.

### 5. Verify

1. Screenshot each section (node.screenshot) and check: every card is next to its element, pointers land on the right element, no overlapping cards, no clipped text, embedded components render.
2. Fix only what is broken, then take one final screenshot of that area.

### 6. Report back (short)

1. Page link and what is covered: sections, card counts, what is embedded, what was skipped.
2. Design issues found while reading.
3. Rules you wrote that the design does not show, as a list for the designer to confirm.

## Card format (match exactly)

* Frame name: "Logic Frame / <n> <title>". Vertical auto layout, fixed width 417 (822 when it holds 2 or more embedded components side by side), hug height.
* Fill #FFF7E0. Padding 12 top and bottom, 16 left and right. Gap 10.
* Header row: number badge (22 px circle, #FEAF02, white number in Rubik Medium 12) and title in Rubik Bold 14, #1A1A1A.
* Each block: tag chip, then body text, then any embedded component. Gap 4 inside a block.
* Tag chips (white Rubik Regular 13, radius 3, padding 3 by 6): Behaviour #00B500, Interaction #1056AA, Validation #D95C00.
* Body text: Rubik Regular 12, #1A1A1A, line height 145%.
* Pointer: vector, stroke #FFBF00, weight 2.5, round join, with a 9 px #FFBF00 dot on the target.
* Screen label bar: #00B500, 44 px high, white Rubik Medium 16. Row label bar: #404040, 44 px. Step label bar: #2B2B2B, 34 px.

## Writing rules

1. Always "tap", never "click".
2. Behaviour: what shows, where data comes from, the default state, truncation and limits.
3. Validation: input rules, error messages, when a CTA is enabled.
4. Interaction: one action per line in the form "Tap X: result."
5. Use braces for dynamic values: {Brand}, {Model}, {City}, {n}, {Author name}.
6. Write UI labels exactly as the design shows them (CHECK LOAN OFFER), but use the correct spelling when the design has a typo, and flag the typo in the report.
7. Point to other sections instead of repeating them: "Refer Get Offers section."
8. Short, plain sentences. No dash characters; use colons and commas.

## Standard logic rules (always apply)

1. FAQs: first FAQ expanded by default, only one open at a time, max 10.
2. Every horizontal section (cards, chips, tabs, carousels) is noted as horizontally scrollable.
3. Clipped card: if 50% or more of a card is visible, tap redirects directly. If less than 50% is visible, the card first snaps into view, then redirects.
4. Cross sell: section horizontally scrollable, first tab selected by default, View All goes to the PLP.

## Default rules (use when the design is silent, and list them in the report)

1. Read more: collapsed text shows 2 or 3 lines, Read more expands it and the label changes to Read less.
2. Info icon: opens its info drawer. CONTINUE or a tap outside closes it.
3. Drawer close icon: closes with no change.
4. Tabs: first tab selected by default. A tab with 0 items is hidden.
5. Anchor tabs: sticky on scroll, active tab underlined and updated on scroll, tap scrolls to the section, scroll to top button at the end.
6. Carousel with dots: swipe moves to the next item and updates the active dot.
7. Mobile number: 10 digits starting with 6, 7, 8 or 9. Inline error for an invalid number. CTA disabled until valid. A consent checkbox, when present, is mandatory.
8. OTP: 6 boxes, focus moves to the next box, Resend OTP enables after the timer, Change returns to the number step with the number prefilled, a wrong OTP shows an inline error and clears the boxes.
9. Toasts show for 3 seconds.
10. When a selection changes (model, variant, city), every dependent section refreshes.
11. Card titles truncate at 2 lines and descriptions at 3 lines, then ellipsis.

## Figma build notes

1. Switch page at most once per use_figma call.
2. On very large sections, get_metadata output is huge. Extract text with use_figma instead (visible TEXT nodes per child frame).
3. Text inside instances of a freshly cloned frame may not be findable in the same call. Find pointer targets in a later call, or measure them on the source node and map the offset onto the clone.
4. Text in nodes on a page that is not current may come back incomplete. Read text while on the source page.
5. Connector nodes are not available in design files. Draw pointers as vectors plus an ellipse dot.
6. Slice exports do not render images. Use node.screenshot() for visual checks.
7. Return created node IDs from every write call, and check partial changes after any failed call before retrying.